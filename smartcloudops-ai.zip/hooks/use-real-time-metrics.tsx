"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { useWebSocket } from "./use-websocket"

interface MetricData {
  timestamp: string
  value: number
  status: "healthy" | "warning" | "critical"
}

interface SystemMetrics {
  cpu: MetricData
  memory: MetricData
  disk: MetricData
  network: MetricData
}

interface UseRealTimeMetricsConfig {
  enableWebSocket?: boolean
  fallbackInterval?: number
  retryDelay?: number
}

export function useRealTimeMetrics(config: UseRealTimeMetricsConfig = {}) {
  const { enableWebSocket = true, fallbackInterval = 5000, retryDelay = 1000 } = config

  const [metrics, setMetrics] = useState<SystemMetrics>({
    cpu: { timestamp: new Date().toISOString(), value: 45, status: "healthy" },
    memory: { timestamp: new Date().toISOString(), value: 72, status: "warning" },
    disk: { timestamp: new Date().toISOString(), value: 34, status: "healthy" },
    network: { timestamp: new Date().toISOString(), value: 89, status: "critical" },
  })

  const [connectionStatus, setConnectionStatus] = useState<"connected" | "connecting" | "disconnected" | "fallback">(
    "disconnected",
  )

  const fallbackIntervalRef = useRef<NodeJS.Timeout>()
  const retryTimeoutRef = useRef<NodeJS.Timeout>()

  const webSocket = useWebSocket({
    url: process.env.NEXT_PUBLIC_WS_URL || "ws://localhost:3001/metrics",
    reconnectInterval: retryDelay,
    maxReconnectAttempts: 3,
    heartbeatInterval: 30000,
  })

  const generateMockMetrics = useCallback((): SystemMetrics => {
    const now = new Date().toISOString()
    return {
      cpu: {
        timestamp: now,
        value: Math.max(0, Math.min(100, metrics.cpu.value + (Math.random() - 0.5) * 10)),
        status: metrics.cpu.value > 80 ? "critical" : metrics.cpu.value > 60 ? "warning" : "healthy",
      },
      memory: {
        timestamp: now,
        value: Math.max(0, Math.min(100, metrics.memory.value + (Math.random() - 0.5) * 8)),
        status: metrics.memory.value > 85 ? "critical" : metrics.memory.value > 70 ? "warning" : "healthy",
      },
      disk: {
        timestamp: now,
        value: Math.max(0, Math.min(100, metrics.disk.value + (Math.random() - 0.5) * 5)),
        status: metrics.disk.value > 90 ? "critical" : metrics.disk.value > 75 ? "warning" : "healthy",
      },
      network: {
        timestamp: now,
        value: Math.max(0, Math.min(100, metrics.network.value + (Math.random() - 0.5) * 12)),
        status: metrics.network.value > 85 ? "critical" : metrics.network.value > 65 ? "warning" : "healthy",
      },
    }
  }, [metrics])

  const startFallbackPolling = useCallback(() => {
    if (fallbackIntervalRef.current) {
      clearInterval(fallbackIntervalRef.current)
    }

    setConnectionStatus("fallback")
    fallbackIntervalRef.current = setInterval(() => {
      setMetrics(generateMockMetrics())
    }, fallbackInterval)
  }, [generateMockMetrics, fallbackInterval])

  const stopFallbackPolling = useCallback(() => {
    if (fallbackIntervalRef.current) {
      clearInterval(fallbackIntervalRef.current)
      fallbackIntervalRef.current = undefined
    }
  }, [])

  useEffect(() => {
    if (!enableWebSocket) {
      startFallbackPolling()
      return
    }

    const removeHandler = webSocket.addMessageHandler((data) => {
      if (data.type === "metrics") {
        setMetrics(data.payload)
      }
    })

    return removeHandler
  }, [enableWebSocket, webSocket.addMessageHandler, startFallbackPolling])

  useEffect(() => {
    if (!enableWebSocket) return

    if (webSocket.isConnected) {
      setConnectionStatus("connected")
      stopFallbackPolling()
    } else if (webSocket.isConnecting) {
      setConnectionStatus("connecting")
    } else if (webSocket.error && webSocket.reconnectAttempts >= 3) {
      // Fallback to polling after max reconnect attempts
      startFallbackPolling()
    } else {
      setConnectionStatus("disconnected")
    }
  }, [
    enableWebSocket,
    webSocket.isConnected,
    webSocket.isConnecting,
    webSocket.error,
    webSocket.reconnectAttempts,
    startFallbackPolling,
    stopFallbackPolling,
  ])

  useEffect(() => {
    if (webSocket.isConnected) {
      webSocket.sendMessage({ type: "subscribe", channel: "metrics" })
    }
  }, [webSocket.isConnected, webSocket.sendMessage])

  // Cleanup
  useEffect(() => {
    return () => {
      stopFallbackPolling()
      if (retryTimeoutRef.current) {
        clearTimeout(retryTimeoutRef.current)
      }
    }
  }, [stopFallbackPolling])

  const refreshMetrics = useCallback(() => {
    if (webSocket.isConnected) {
      webSocket.sendMessage({ type: "refresh", channel: "metrics" })
    } else {
      setMetrics(generateMockMetrics())
    }
  }, [webSocket.isConnected, webSocket.sendMessage, generateMockMetrics])

  return {
    metrics,
    connectionStatus,
    refreshMetrics,
    isRealTime: connectionStatus === "connected",
    error: webSocket.error,
  }
}
