"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { SLAIndicator, type SLAMetric } from "@/components/sla-indicator"
import { CostOptimizationCard, type CostOptimization } from "@/components/cost-optimization-card"
import { ServiceDependencyGraph, type ServiceNode } from "@/components/service-dependency-graph"
import { AuditLog, type AuditLogEntry } from "@/components/audit-log"
import { BarChart, TrendingUp, DollarSign, Network, FileText } from "lucide-react"

// Mock data
const mockSLAMetrics: SLAMetric[] = [
  {
    id: "sla-1",
    name: "API Availability",
    current: 99.97,
    target: 99.95,
    trend: "up",
    status: "healthy",
    period: "Last 30 days",
    description: "Overall API uptime across all services",
  },
  {
    id: "sla-2",
    name: "Response Time",
    current: 245,
    target: 300,
    trend: "stable",
    status: "healthy",
    period: "Last 24 hours",
    description: "Average response time in milliseconds",
  },
  {
    id: "sla-3",
    name: "Error Rate",
    current: 0.12,
    target: 0.1,
    trend: "down",
    status: "warning",
    period: "Last 7 days",
    description: "Percentage of requests resulting in errors",
  },
  {
    id: "sla-4",
    name: "Database Performance",
    current: 98.2,
    target: 99.0,
    trend: "down",
    status: "critical",
    period: "Last 24 hours",
    description: "Database query performance and availability",
  },
]

const mockCostOptimizations: CostOptimization[] = [
  {
    id: "cost-1",
    title: "Right-size EC2 Instances",
    description: "Several instances are over-provisioned based on actual usage patterns",
    potentialSavings: 2400,
    currentCost: 8500,
    category: "compute",
    priority: "high",
    aiConfidence: 94,
    implementationEffort: "low",
    estimatedTimeToImplement: "2-3 hours",
  },
  {
    id: "cost-2",
    title: "Optimize S3 Storage Classes",
    description: "Move infrequently accessed data to cheaper storage tiers",
    potentialSavings: 1200,
    currentCost: 3200,
    category: "storage",
    priority: "medium",
    aiConfidence: 87,
    implementationEffort: "medium",
    estimatedTimeToImplement: "1-2 days",
  },
  {
    id: "cost-3",
    title: "Database Connection Pooling",
    description: "Implement connection pooling to reduce database instance requirements",
    potentialSavings: 800,
    currentCost: 2500,
    category: "database",
    priority: "medium",
    aiConfidence: 91,
    implementationEffort: "high",
    estimatedTimeToImplement: "1 week",
  },
]

const mockServices: ServiceNode[] = [
  {
    id: "api-gateway",
    name: "API Gateway",
    type: "api",
    status: "healthy",
    dependencies: ["user-service", "payment-service", "redis-cache"],
  },
  {
    id: "user-service",
    name: "User Service",
    type: "api",
    status: "healthy",
    dependencies: ["postgres-db", "redis-cache"],
  },
  {
    id: "payment-service",
    name: "Payment Service",
    type: "api",
    status: "warning",
    dependencies: ["postgres-db", "stripe-api"],
  },
  {
    id: "postgres-db",
    name: "PostgreSQL",
    type: "database",
    status: "critical",
    dependencies: [],
  },
  {
    id: "redis-cache",
    name: "Redis Cache",
    type: "cache",
    status: "healthy",
    dependencies: [],
  },
  {
    id: "stripe-api",
    name: "Stripe API",
    type: "external",
    status: "healthy",
    dependencies: [],
  },
]

const mockAuditEntries: AuditLogEntry[] = [
  {
    id: "audit-1",
    timestamp: "2024-01-15T10:30:00Z",
    user: "john.doe@company.com",
    action: "Executed Remediation Action",
    resource: "api-gateway",
    category: "remediation",
    severity: "info",
    details: "Restarted API Gateway service to resolve memory leak",
    ipAddress: "192.168.1.100",
  },
  {
    id: "audit-2",
    timestamp: "2024-01-15T09:45:00Z",
    user: "jane.smith@company.com",
    action: "Updated SLA Threshold",
    resource: "response-time-sla",
    category: "configuration",
    severity: "warning",
    details: "Changed response time threshold from 250ms to 300ms",
    ipAddress: "192.168.1.101",
  },
  {
    id: "audit-3",
    timestamp: "2024-01-15T09:20:00Z",
    user: "admin@company.com",
    action: "Failed Login Attempt",
    resource: "authentication-system",
    category: "security",
    severity: "critical",
    details: "Multiple failed login attempts detected from suspicious IP",
    ipAddress: "203.0.113.42",
  },
]

export default function InsightsPage() {
  const handleImplementOptimization = (id: string) => {
    console.log("[v0] Implementing cost optimization:", id)
    // Implementation logic would go here
  }

  const totalPotentialSavings = mockCostOptimizations.reduce((sum, opt) => sum + opt.potentialSavings, 0)
  const healthySLAs = mockSLAMetrics.filter((m) => m.status === "healthy").length
  const criticalServices = mockServices.filter((s) => s.status === "critical").length

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-3">
          <BarChart className="h-8 w-8 text-teal-400" />
          Advanced Insights
        </h1>
        <p className="text-muted-foreground">Enterprise analytics, SLA monitoring, and cost optimization insights</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-teal-500/20 bg-teal-500/5">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-teal-400 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Healthy SLAs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-teal-400">
              {healthySLAs}/{mockSLAMetrics.length}
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-500/20 bg-green-500/5">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-green-400 flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Potential Savings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">${totalPotentialSavings.toLocaleString()}</div>
          </CardContent>
        </Card>

        <Card className="border-red-500/20 bg-red-500/5">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-red-400 flex items-center gap-2">
              <Network className="h-4 w-4" />
              Critical Services
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-400">{criticalServices}</div>
          </CardContent>
        </Card>

        <Card className="border-blue-500/20 bg-blue-500/5">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-blue-400 flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Audit Events
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-400">{mockAuditEntries.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* SLA Indicators */}
      <div>
        <h2 className="text-xl font-semibold mb-4 text-teal-400">SLA/SLI Indicators</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {mockSLAMetrics.map((metric) => (
            <SLAIndicator key={metric.id} metric={metric} />
          ))}
        </div>
      </div>

      {/* Cost Optimizations */}
      <div>
        <h2 className="text-xl font-semibold mb-4 text-teal-400">AI-Driven Cost Optimizations</h2>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {mockCostOptimizations.map((optimization) => (
            <CostOptimizationCard
              key={optimization.id}
              optimization={optimization}
              onImplement={handleImplementOptimization}
            />
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Service Dependencies */}
        <ServiceDependencyGraph services={mockServices} />

        {/* Audit Log */}
        <AuditLog entries={mockAuditEntries} />
      </div>
    </div>
  )
}
